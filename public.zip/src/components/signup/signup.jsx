import React from 'react';

function SignUp() {
    return (  );
}

export default SignUp;